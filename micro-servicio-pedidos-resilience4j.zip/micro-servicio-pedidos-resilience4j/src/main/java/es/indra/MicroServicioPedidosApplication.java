package es.indra;

import java.time.Duration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JConfigBuilder;
import org.springframework.cloud.client.circuitbreaker.Customizer;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;

@SpringBootApplication
@EnableFeignClients
@EnableEurekaClient
public class MicroServicioPedidosApplication {
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	// Crear un bean para configurar Parámetros de Circuit Breaker
//	@Bean
//	public Customizer<Resilience4JCircuitBreakerFactory>  defaultCustomizer(){
//		return rFactory -> rFactory.configureDefault(id -> {
//			return new Resilience4JConfigBuilder(id)
//					.circuitBreakerConfig(CircuitBreakerConfig.custom()
//						.slidingWindowSize(10)
//						.failureRateThreshold(50)
//						.waitDurationInOpenState(Duration.ofSeconds(20L))
//						.permittedNumberOfCallsInHalfOpenState(5)
//						
//						// agregar las 2 propiedades para configurar llamadas lentas
//						.slowCallDurationThreshold(Duration.ofSeconds(2L))
//						.slowCallRateThreshold(50)
//						
//						.build())
//					//.timeLimiterConfig(TimeLimiterConfig.ofDefaults())
//					.timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.ofSeconds(6L)).build()   )
//					.build();
//		});	
//	}
	

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPedidosApplication.class, args);
	}

}
