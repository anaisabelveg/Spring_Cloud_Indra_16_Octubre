package es.indra.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Pedido;
import es.indra.models.Producto;
import es.indra.services.IPedidoService;

@RestController
public class PedidoController {
	
	// Con autowired no me permite poner el nombre del bean a inyectar
	//@Autowired
	//@Qualifier("serviceRestTemplate")
	
	// Con Resource si que me permite poner el nombre
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	
	@Autowired
	private CircuitBreakerFactory cbFactory;
	
	
	// En caso de recibir una excepcion llamamos al metodo manejarError
	// http://localhost:8002/buscar/4/cantidad/50
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return cbFactory.create("pedidos")
				.run(() -> service.realizarPedido(id, cantidad), e -> manejarError(id, cantidad, e) );
	}
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "***************");
		System.out.println(ex.getClass() + "-------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
