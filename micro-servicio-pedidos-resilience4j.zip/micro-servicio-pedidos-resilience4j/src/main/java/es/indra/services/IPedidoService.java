package es.indra.services;

import es.indra.models.Pedido;

public interface IPedidoService {
	
	Pedido realizarPedido(Long id, int cantidad);

}
