package es.indra.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// http://localhost:8001/todos
	@GetMapping("/todos")
	public List<Producto> todos(){
		return productoService.consultarTodos();
	}
	
	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) {
		return productoService.buscarProducto(id);
	}

}
