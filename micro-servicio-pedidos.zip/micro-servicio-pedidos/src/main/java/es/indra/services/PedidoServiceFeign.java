package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteRest;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service("serviceFeign")
// Le damos preferencia en la inyeccion de propiedades
//@Primary
public class PedidoServiceFeign implements IPedidoService{
	
	@Autowired
	private ProductosClienteRest clienteFeign;

	@Override
	public Pedido realizarPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
