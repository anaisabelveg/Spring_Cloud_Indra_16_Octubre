package es.indra.persistence;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.indra.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS", path = "productos")
public interface ProductosDAO extends CrudRepository<Producto, Long>{
	
	// Consultar todos los productos
	// http://localhost:8001/productos
	
	
	// Si quereis crear metodos personalizados
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// http://localhost:8001/productos/search/findByDescripcion?descripcion=Raton
	public List<Producto> findByDescripcion(String descripcion);
	
	// http://localhost:8001/productos/search/findByPrecioBetween?min=100&max=300
	public List<Producto>  findByPrecioBetween(double min, double max);
	
	// Todos los metodos implementados se pueden ver en esta url
	// http://localhost:8001/productos/search

}
