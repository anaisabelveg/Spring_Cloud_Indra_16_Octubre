package es.indra.persistence;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.indra.models.Usuario;

@RepositoryRestResource(path = "usuarios")
public interface UsuarioDAO extends PagingAndSortingRepository<Usuario, Long>{
	
	// Ver todos los usuarios
	// http://localhost:8011/usuarios
	
	// http://localhost:8011/usuarios/search/findByUsername?username=anabel
	public Usuario findByUsername(String username);

}
