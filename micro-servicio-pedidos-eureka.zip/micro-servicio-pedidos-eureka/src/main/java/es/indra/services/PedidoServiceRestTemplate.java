package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service("serviceRestTemplate")
public class PedidoServiceRestTemplate implements IPedidoService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido realizarPedido(Long id, int cantidad) {
		//Este cliente siempre lanza la peticion al puerto 8001,
		//esta demasiado acoplada
//		Producto producto = restTemplate.getForObject("http://localhost:8001/buscar/{id}", 
//				Producto.class, id);
		
		Producto producto = restTemplate.getForObject("http://servicio-productos/buscar/{id}", 
				Producto.class, id);
		return new Pedido(producto, cantidad);
	}

}
