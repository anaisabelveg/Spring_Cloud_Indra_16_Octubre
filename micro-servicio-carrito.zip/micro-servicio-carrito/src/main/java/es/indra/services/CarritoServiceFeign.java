package es.indra.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteRest;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritoDAO;

@Service
public class CarritoServiceFeign implements ICarritoService{
	
	@Autowired
	private CarritoDAO dao;
	
	@Autowired
	private PedidosClienteRest clienteFeign;
	

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		return dao.save(carrito);
	}
	
	@Override
	public Carrito buscar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito agregarPedido(Long id, int cantidad, String usuario) {
		Pedido pedido = clienteFeign.crearPedido(id, cantidad);
		Carrito carrito = dao.findByUsuario(usuario);
		carrito.getContenido().add(pedido);
		carrito.setImporte(carrito.getImporte() + 
				(pedido.getProducto().getPrecio() * cantidad));
		dao.save(carrito);
		return carrito;
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = dao.findByUsuario(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		Pedido encontrado = null;
		for(Pedido pedido : contenido) {
			if (id == pedido.getProducto().getID()) {
				encontrado = pedido;
				break;
			}
		}
		
		contenido.remove(encontrado);
		carrito.setImporte(carrito.getImporte() -
				(encontrado.getProducto().getPrecio() * encontrado.getCantidad()));
		
		return carrito;
	}

}
