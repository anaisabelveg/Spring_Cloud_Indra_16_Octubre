package es.indra.filters;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class MedirTiempoFilter implements GlobalFilter, Ordered{

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		// Configuramos que hacemos en el pre y post
		
		// pre
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		
		// post es lo que hay en .then()
		return chain.filter(exchange).then(Mono.fromRunnable( () -> {
			// Tomar el tiempo final
			Long tiempoFinal = System.currentTimeMillis();
			
			// Mostrar la diferencia de tiempos en consola
			System.out.println("**************************************");
			System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio + " mseg."));
			System.out.println("**************************************");
		} ))   ;
	}

	@Override
	public int getOrder() {
		// Orden de ejecuccion en el caso de tener varios filtros
		return 1;
	}

}
