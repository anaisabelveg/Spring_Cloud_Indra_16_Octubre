package es.indra.services;

import es.indra.models.Carrito;

public interface ICarritoService {
	
	Carrito crear(String usuario);
	
	Carrito agregarPedido(Long id, int cantidad, String usuario);
	
	Carrito buscar(String usuario);
	
	Carrito eliminarPedido(Long id, String usuario);

}
