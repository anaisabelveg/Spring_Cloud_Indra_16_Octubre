package es.indra.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.indra.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "carritos", path = "carritos")
public interface CarritoDAO extends MongoRepository<Carrito, String>{

	// http://localhost:8003/carritos
	
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Pepito
	public Carrito findByUsuario(String usuario);
}
