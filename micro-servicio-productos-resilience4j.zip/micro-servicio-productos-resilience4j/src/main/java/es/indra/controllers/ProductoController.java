package es.indra.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// Con puerto dinamico no funciona
	//@Value("${server.port}")
	//private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	
	// http://localhost:8001/todos
	@GetMapping("/todos")
	public List<Producto> todos(){
		return productoService.consultarTodos().stream()
				.map(prod -> {
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		Producto producto = productoService.buscarProducto(id);
		
		// Si el producto no existe, lanzar Excepcion
		if (producto.getPrecio() == 0) {
			throw new IllegalStateException("El producto no existe");
		}
		
		// Vamos a configurar las llamadas lentas
		// Por defecto, el timeout es de 1 segundo.
		// Provocamos el error parando el hilo 5 segundos cuando el id sea 5
		if (id.equals(5L))
			Thread.sleep(5_000);
		
		producto.setPort(request.getLocalPort());
		return producto;
	}

}













