package es.indra.controllers;

import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Pedido;
import es.indra.models.Producto;
import es.indra.services.IPedidoService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;

@RefreshScope
@RestController
public class PedidoController {
	
	
	// Inyectar el texto de prueba recibido del servidor de configuracion
	@Value("${configuration.prueba}")
	private String texto;
	
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	
	@Autowired
	private CircuitBreakerFactory cbFactory;
	
	
	// En caso de recibir una excepcion llamamos al metodo manejarError
	// http://localhost:8002/buscar/4/cantidad/50
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		
		// Mostrar el texto
		System.out.println("----------------------------");
		System.out.println(texto);
		System.out.println("----------------------------");
		
		// Forma programatica
		return cbFactory.create("pedidos")
				.run(() -> service.realizarPedido(id, cantidad), e -> manejarError(id, cantidad, e) );
	}
	
	// Si utilizamos anotaciones solo vale la configuracion del .properties o yaml
	// No funciona la configuracion del @Bean
	// http://localhost:8002/buscar2/4/cantidad/50
	@GetMapping("/buscar2/{id}/cantidad/{cantidad}")
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError")
	public Pedido crearPedido2(@PathVariable Long id, @PathVariable int cantidad) {
		return service.realizarPedido(id, cantidad);
	}
	
	// http://localhost:8002/buscar3/5/cantidad/50
	@GetMapping("/buscar3/{id}/cantidad/{cantidad}")
	@TimeLimiter(name = "pedidos")
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError2")
	public CompletableFuture<Pedido> crearPedido3(@PathVariable Long id, @PathVariable int cantidad) {
		return CompletableFuture.supplyAsync(() -> service.realizarPedido(id, cantidad));
	}
	
	public CompletableFuture<Pedido> manejarError2(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "***************");
		System.out.println(ex.getClass() + "-------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto lento");
		producto.setPrecio(0);
		
		Pedido pedido = new Pedido(producto, cantidad);
		return CompletableFuture.supplyAsync(() -> pedido);
	}
	
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "***************");
		System.out.println(ex.getClass() + "-------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
















